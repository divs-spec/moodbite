# 🍴 Mise en Place — Personalized Meal Intelligence

AI-powered meal planning app built with **Next.js 14** and **Claude claude-opus-4-6**. Suggests fully cooked meals based on your mood, dietary needs, calorie target, cuisine preference, and meal time.

---

## ✦ Features

- 6 meal-time categories (Breakfast, Elevenses, Brunch, Lunch, Snack, Dinner)
- Mood-aware recommendations
- Multi-cuisine filtering (no fusion)
- Dietary constraint support (Veg / Vegan / GF / Dairy-Free / Non-Veg)
- Calorie-adjusted portions per meal time
- Secure API route — API key never exposed to the browser

---

## 🚀 Local Development

### 1. Clone & install

```bash
git clone https://github.com/YOUR_USERNAME/mise-en-place.git
cd mise-en-place
npm install
```

### 2. Set your API key

```bash
cp .env.local.example .env.local
```

Edit `.env.local` and replace `your_api_key_here` with your actual key from [console.anthropic.com](https://console.anthropic.com).

```env
ANTHROPIC_API_KEY=sk-ant-...
```

### 3. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## ☁️ Deploy to Vercel

### Option A — Vercel CLI (fastest)

```bash
npm i -g vercel
vercel
```

Follow the prompts. When asked about environment variables, add `ANTHROPIC_API_KEY`.

### Option B — GitHub → Vercel Dashboard

1. Push this repo to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. In **Environment Variables**, add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-...` (your key from console.anthropic.com)
5. Click **Deploy**

> ⚠️ Never commit `.env.local` to git — it's already in `.gitignore`.

---

## 📁 Project Structure

```
mise-en-place/
├── app/
│   ├── api/
│   │   └── recommend/
│   │       └── route.js      ← Secure server-side Anthropic API proxy
│   ├── globals.css
│   ├── layout.js
│   └── page.js               ← Full multi-step UI
├── components/
│   └── ui.js                 ← Reusable UI primitives
├── lib/
│   └── constants.js          ← Meal times, moods, cuisines, dietary
├── .env.local.example        ← Template — copy to .env.local
├── .gitignore
├── next.config.js
└── package.json
```

---

## 🔐 Security Notes

- The Anthropic API key is stored as a **server-side environment variable**
- The browser calls `/api/recommend` — never Anthropic directly
- The Next.js API route runs on Vercel's serverless edge — key is never leaked

---

## 🛠 Built With

- [Next.js 14](https://nextjs.org) (App Router)
- [Anthropic SDK](https://github.com/anthropics/anthropic-sdk-node)
- Claude claude-opus-4-6
